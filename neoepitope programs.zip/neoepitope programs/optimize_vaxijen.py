import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    normseq=[]
    for indnorm in range(len(seq)):
        normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]

rvax=open("results_vaxijen.txt","w")
# opens the file in which the vaxijen values are written (with an empty line at the beginning!)
vaxi=open("vaxijen_non_normalized.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of vaxijen values
  vaxijen=[]
# reads blank line
  bl=vaxi.readline()
# writtes blank line
  rvax.write("\n")
# reads patient code
  np=vaxi.readline()[:-1]
  print(np)
  rvax.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):

    hrl=vaxi.readline()[:-1].split(",")

# adds neoepitope to list (removing the endline)
    lepit.append(hrl[0])


# reads vaxyjen value
    grv=eval(hrl[1])
    print(grv)
# adds gravi value to list
    vaxijen.append(grv)
  print(vaxijen)
# normalizes the list of vaxijen values
  vaxijen2=norm(vaxijen)
  print(vaxijen2)
  print(lepit)
  for i in range(x):
    rvax.write(lepit[i]+","+str(vaxijen2[i])+"\n")


      
 
