import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    if maxseq==0 and minseq==0:
      normseq=seq
    else:
      normseq=[]
      for indnorm in range(len(seq)):
          normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]

rtpr=open("results_TAP_proteo.txt","w")
# opens the file in which the hla1 binding affinity are written (with an empty line at the beginning!)
ftpr=open("TAP_proteo_non_normalized.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of TAP and proteo values
  vtpr=[]
# reads blank line
  bl=ftpr.readline()
# writtes blank line
  rtpr.write("\n")
# reads patient code
  np=ftpr.readline()[:-1]
  print(np)
  rtpr.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):

    hrl=ftpr.readline()[:-1].split(",")

# adds neoepitope to list (removing the endline)
    lepit.append(hrl[0])


# reads TAP proteo value
    tpr=eval(hrl[1])
    print(tpr)
# adds gravi value to list
    vtpr.append(tpr)
  print(vtpr)
# normalizes the list of binding affinity values
  vtprbis=norm(vtpr)
  print(vtprbis)
  print(lepit)
  for i in range(x):
    rtpr.write(lepit[i]+","+str(vtprbis[i])+"\n")


      
 
