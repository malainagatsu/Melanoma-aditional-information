import Bio
from Bio import SeqIO
from Bio import Entrez
from pandas import DataFrame, read_csv
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np 
 
file = r'613.xlsx'
df = pd.read_excel(file)
df = df.fillna('')
c=df['Chromosome']
p=df['Position']
t=df['Transcript']
e=df['Exon']
g=df['Gene']
r=df['Ref']
a=df['Alt']

tr=set()
for i in range(len(df)):
  if e[i]!='' and t[i]!='':
    print("i=",i,"Chromosome=",c[i],"Position=",p[i],"Ref=",r[i],"Alt=",a[i])
    tr.add(t[i])
    print('')
print(tr)
print(len(tr))

for i in tr:
  print(i)
  handle = Entrez.efetch(db="nucleotide", id=i, rettype="fasta", retmode="text")
  file=open("/home/l/transcripts/"+i+".fa","w")
  file.write(handle.read())
  file.close()
