import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    if maxseq==0 and minseq==0:
      normseq=seq
    else:
      normseq=[]
      for indnorm in range(len(seq)):
          normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]
rimmun=open("results_immunogenicity.txt","w")

# opens the file in which the neoepitopes are written (with an empty line at the beginning!)
neoep=open("neoepitopes.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of immunogenicities
  vinmun=[]
# reads blank line
  bl=neoep.readline()
# writtes blank line
  rimmun.write("\n")
# reads patient code
  np=neoep.readline()[:-1]
  print(np)
  rimmun.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):
# reads neoepitope
    instneoep=neoep.readline()
# adds neoepitope to list (removing the endline)
    lepit.append(instneoep[:-1])
# address of the file of immunogenicities
  fa='/home/l/inmunogenicity/inmun_'+np+'.txt'
  print()
  finmuno=open(fa,"r")
  lterns=[]
  for line in finmuno:
    tern=line[:-1].split(",")
    tern[1]=eval(tern[1])
    tern[2]=eval(tern[2])
    lterns.append(tern)   
  print(lterns)
  for i in lepit:
    print(i)
    linmbynine=[]
    for j in range(len(i)-8):
      psearch=i[j:j+9]
      for k in lterns:
        if psearch==k[0]:
          linmbynine.append(k[2])
    vinmun.append(statistics.mean(linmbynine))


# normalizes the list of immunogenicities
  print(vinmun)
  vinmunbis=norm(vinmun)
  print(vinmunbis)
  print(lepit)
  for i in range(x):
    rimmun.write(lepit[i]+","+str(vinmunbis[i])+"\n")
    
  print(bl)




      
 
