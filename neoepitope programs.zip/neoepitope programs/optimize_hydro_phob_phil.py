import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    normseq=[]
    for indnorm in range(len(seq)):
        normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]

rhydr=open("results_hydrophilicity.txt","w")
# opens the file in which the gravy values are written (with an empty line at the beginning!)
hydro=open("hydrophobicity_non_normalized.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of GRAVY values
  gravy=[]
# reads blank line
  bl=hydro.readline()
# writtes blank line
  rhydr.write("\n")
# reads patient code
  np=hydro.readline()[:-1]
  print(np)
  rhydr.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):

    hrl=hydro.readline()[:-1].split(",")

# adds neoepitope to list (removing the endline)
    lepit.append(hrl[0])


# reads gravy value
    grv=eval(hrl[1])
    print(grv)
# adds gravi value to list
    gravy.append(grv)
  print(gravy)
# normalizes the list of gravy values
  gravy2=norm(gravy)
  print(gravy2)
  print(lepit)
# takes 1-x, because we are interested in hydrophilic peptides
  for i in range(x):
    gravy2[i]=1-gravy2[i]
  print(gravy2)
  for i in range(x):
    rhydr.write(lepit[i]+","+str(gravy2[i])+"\n")


      
 
