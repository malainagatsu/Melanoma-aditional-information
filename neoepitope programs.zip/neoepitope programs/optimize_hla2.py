import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    if maxseq==0 and minseq==0:
      normseq=seq
    else:
      normseq=[]
      for indnorm in range(len(seq)):
          normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]

rhla2=open("results_hla2.txt","w")
# opens the file in which the hla2 binding affinity are written (with an empty line at the beginning!)
fhla2=open("hla2_non_normalized.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of binding affinities
  vhla2=[]
# reads blank line
  bl=fhla2.readline()
# writtes blank line
  rhla2.write("\n")
# reads patient code
  np=fhla2.readline()[:-1]
  print(np)
  rhla2.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):

    hrl=fhla2.readline()[:-1].split(",")

# adds neoepitope to list (removing the endline)
    lepit.append(hrl[0])


# reads binding affinity value
    baff=eval(hrl[1])
    print(baff)
# adds gravi value to list
    vhla2.append(baff)
  print(vhla2)
# normalizes the list of binding affinity values
  vhla2bis=norm(vhla2)
  print(vhla2bis)
  print(lepit)
  for i in range(x):
    rhla2.write(lepit[i]+","+str(vhla2bis[i])+"\n")


      
 
