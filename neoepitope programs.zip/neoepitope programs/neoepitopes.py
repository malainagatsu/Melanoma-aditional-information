import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from Bio.Alphabet import IUPAC



postrs=open("positions_and_transcripts.txt","x")



def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1: return
        yield start
        start += len(sub) # use start += 1 to find overlapping matches




 
file = r'613.xlsx'
df = pd.read_excel(file)
df = df.fillna('')
c=df['Chromosome']
p=df['Position']
t=df['Transcript']
e=df['Exon']
g=df['Gene']
r=df['Ref']
a=df['Alt'] 

mutations_list=[]
nom=0
noi=0
nod=0
for i in range(10):
  if e[i]!='' and t[i]!='':
    print("i=",i,"Chromosome=",c[i],"Position=",p[i],"Ref=",r[i],"Alt=",a[i],"transcript=",t[i])
    print('')
 
    strchr='/home/l/chromosomeshg19/chr'+str(c[i])+'.fa'








    s=SeqIO.parse(strchr,"fasta")
    for sr in s:
      strchr2='/home/l/transcripts/'+str(t[i])+'.fa'
      s2=SeqIO.parse(strchr2,"fasta")
      for sr2 in s2:
        length_neighbourhood=len(sr2.seq)-1
      u=sr[p[i]-1-int(0.0025*len(sr2.seq)):p[i]+int(0.0025*len(sr2.seq))].seq
      print("Entorno: ",u)
      print('')
      print("reverso complementario del entorno: ",u.reverse_complement())
      print('')
      llim=p[i]-1
      rlim=p[i]
      lcs=str(sr[llim:rlim].seq.reverse_complement())
      lcsc=colored(str(sr[llim:rlim].seq.reverse_complement()),'red')
      if not (str(sr[llim:rlim].seq.reverse_complement()) in str(sr2.seq)):
        print("there is no common substring containing the base")
      else:
        
        while str(sr[llim-1:rlim].seq.reverse_complement()) in str(sr2.seq):
          llim=llim-1
          prs=sr[llim:rlim].seq
          lcs=prs.reverse_complement()
          lcsc=lcsc+colored(str(sr[llim:llim+1].seq.reverse_complement()),'green')


      poscount=0
      while str(sr[llim:rlim+1].seq.reverse_complement()) in str(sr2.seq):
        poscount=poscount+1
        rlim=rlim+1
        prs=sr[llim:rlim].seq
        lcs=prs.reverse_complement()
        lcsc=colored(str(sr[rlim-1:rlim].seq.reverse_complement()),'green')+lcsc
      lengthrc=len(lcs)
      lpt=list(find_all(str(sr2.seq), str(lcs)))
      if len(lpt)==1:
        istrng=sr2[0:lpt[0]]
        fstrng=sr2[lpt[0]+len(lcs):len(str(sr2.seq))]
        clrtranscript=str(istrng.seq)+lcsc+str(fstrng.seq)
        clrtranscriptrevcomp=str(istrng.seq)+lcsc+str(fstrng.seq)        
        prb=len(str(istrng.seq))+poscount
        prbrc=len(str(istrng.seq))+poscount
        if r[i]!='-' and a[i]!='-':
          rnamutrevcomp=[t[i],'m',prb,Seq(a[i],IUPAC.unambiguous_dna).complement()]
        if r[i]=='-' and a[i]!="-":
          rnamutrevcomp=[t[i],'i',prb,a[i]]
        if r[i]!="-" and a[i]=="-":
         rnamutrevcomp=[t[i],'d',prb,r[i]]
        












      strchr2='/home/l/transcripts/'+str(t[i])+'.fa'
      s2=SeqIO.parse(strchr2,"fasta")
      for sr2 in s2:
        length_neighbourhood=len(sr2.seq)-1
      u=sr[p[i]-1-int(0.0025*len(sr2.seq)):p[i]+int(0.0025*len(sr2.seq))].seq
      llim=p[i]-1
      rlim=p[i]
      lcs=str(sr[llim:rlim])
      lcsc=colored(str(sr[llim:rlim].seq),'red')
      if not (str(sr[llim:rlim].seq) in str(sr2.seq)):
        print("there is no common substring containing the base")
      else:
        
        precount=0
        while str(sr[llim-1:rlim].seq) in str(sr2.seq):
          precount=precount+1
          llim=llim-1
          prs=sr[llim:rlim].seq
          lcs=prs
          lcsc=colored(str(sr[llim:llim+1].seq),'green')+lcsc


      
      while str(sr[llim:rlim+1].seq) in str(sr2.seq):
        rlim=rlim+1
        prs=sr[llim:rlim].seq
        lcs=prs
        lcsc=lcsc+colored(str(sr[rlim-1:rlim].seq),'green')
      lengthd=len(lcs)
      lpt=list(find_all(str(sr2.seq), str(lcs)))
      if len(lpt)==1:
        istrng=sr2[0:lpt[0]]
        fstrng=sr2[lpt[0]+len(lcs):len(str(sr2.seq))]
        clrtranscript=str(istrng.seq)+lcsc+str(fstrng.seq)
        clrtranscriptdir=str(istrng.seq)+lcsc+str(fstrng.seq) 
        prb=len(str(istrng.seq))+precount
        prbd=len(str(istrng.seq))+precount
        if r[i]!='-' and a[i]!='-':
          rnamutdir=[t[i],'m',prb,Seq(a[i],IUPAC.unambiguous_dna).complement()]
        if r[i]=='-' and a[i]!="-":
          rnamutdir=['i',prb,a[i]]
        if r[i]!="-" and a[i]=="-":
         rnamutdir=['d',prb,r[i]]

        if lengthrc>=lengthd:
           print("reverse complement mode")
           print('')
           prb=prbrc
           clrtranscript=clrtranscriptrevcomp
           mutations_list.append(rnamutrevcomp)
        else:
           print("direct mode")
           print('')
           prb=prbd
           clrtranscript=clrtranscriptdir
           mutations_list.append(rnamutdir)
    print("transcript: ",clrtranscript)
    print('')
    print("position (beginning from index 0) of the reference base",prb)
    print('')
    postrs.write(str(i)+","+str(c[i])+","+str(p[i])+","+str(t[i])+"\n") 
for i in mutations_list:
  if i[1]=='m':
    nom=nom+1
  elif i[1]=='i':
    noi=noi+1
  else:
    nod=nod+1 
print('the number of mutations is',nom)
print('the number of insertions is',noi)
print('the number of deletions is',nod)
print('list of mutations: ',mutations_list)
postrs.close() 
