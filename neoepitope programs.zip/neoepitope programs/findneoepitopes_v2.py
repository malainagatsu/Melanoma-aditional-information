import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

# function to calculate the number of differences between two sequences of the same length
def ndifferences(seq1, seq2):
    count = 0
    for indiff in range(len(seq1)):
        if seq1[indiff] != seq2[indiff]:
            count += 1
    return count

lo=LiftOver('hg19','hg38')
# reads the table of correspondence of codes of the patients between mutations in blood and in biopsies 
corresp = r'correspondence.xlsx'
corrf = pd.read_excel(corresp)
germ=corrf['Germinal']
tum=corrf['Tumoral']
#radius of the neoepitopes (the number of aminoacids is 2r+1)
r=7
# opens the file of errors
ef=open("errors.txt","w")
# opens the file in which the neoepitopes are written (with an empty line at the beginning!)
oneoep=open("neoepitopes.txt","w")
# opens the file in which the summary of neoepitopes are written (with an empty line at the beginning!)
summ=open("summaryepit.txt","w")
# opens the file in which the variant frequencies are written (with an empty line at the beginning!)
vf=open("variant_frequencies_non_normalized.txt","w")
# prints the radius of the neoepitopes
print("r="+str(r))
# main loop in the set of patients
for i in range(len(germ)):
# writes the code of the patient in the tumoral biopsies
  print(tum[i])
# reads the table of mutations of the patient in blood
  bloodf=pd.read_excel('/home/l/mutations_blood/'+str(germ[i])+'.xlsx')
# reads the column of chromosomes
  chgerm=bloodf["Chromosome"]
# reads the column of positions
  pogerm=bloodf["Position"]
# reads the table of mutations of the patient in the tumoral biopsies
  biopsiesf=pd.read_excel('/home/l/mutations_biopsies/'+str(tum[i])+'.variants.xlsx')
# reads the column of chromosomes
  chb=biopsiesf["Chromosome"]
# reads the column of positions
  pob=biopsiesf["Position"]
# reads the column of reference allele
  rab=biopsiesf["Reference Allele"]
# reads the column of variant allele
  vab=biopsiesf["Variant Allele"]
# reads the column of variant type
  vtb=biopsiesf["Variant Type"]
# reads the column of sequence context
  scb=biopsiesf["Sequence Context"]
# reads the column of consequence
  csb=biopsiesf["Consequence"]
# reads the column of variant frequency
  cvf=biopsiesf["Variant Frequency"]
# writtes in the output file a blank line and the code (in biopsies) of the patient
  oneoep.write('\n')
  oneoep.write(str(tum[i])+'\n')
# writtes in the file of summary a blank line and the code (in biopsies) of the patient
  summ.write('\n')
  summ.write(str(tum[i])+'\n')
# writtes in the file of variant frequencies a blank line and the code (in biopsies) of the patient
  vf.write('\n')
  vf.write(str(tum[i])+'\n')
# opens the file of unrestricted ubiquous peptides of the patient
  up=open('/home/l/ubiquouspeptides/output_coord_hg38_'+str(tum[i])+' annotated_for_mutations .txt',"r")
# creates a list with the records in the file
  with up as f:
    upc = f.readlines()
    upc = [x.strip() for x in upc]
  up.close()
# initialize the list 'lubpep' of length equal to the number of mutations with values '[]' in all positions  
  lubpep=[]
  for j in range(len(chb)):
    lubpep.append([])
# initialize the list 'nmp' of length equal to the number of mutations with values '[]' in all positions  
  nmp=[]
  for j in range(len(chb)):
    nmp.append([])
# initializes the counter of records
  cont=1
# loop on the ubiquous neoepitopes
  while upc[cont]!='END':
# reads index of mutation, reading frame and transcript of the neoepitope
    lpapo=[upc[cont],upc[cont+1],upc[cont+2]]
    cont=cont+3
# number of items associated to proteins in the mutation
    nrec=upc[cont]
# initialization of set of terns initial position-final position-protein id
    lpapoprot=[]
# initialization to the void set of the protein names
    protnames=set()
# loop in the proteins in the mutation
    for j in range(int(eval(nrec)/3)):
# recording of initial position-final position-protein id
      lpapoprot.append([upc[cont+1],upc[cont+2],upc[cont+3]])
# update of set of the protein names
      protnames.add(upc[cont+3])
# update of counter associated to loop of proteins
      cont=cont+3
# update of counter associated to change of neoepitope
    cont=cont+1
# add to 'lpapo' information about initial position-final position-protein id of the proteins
    lpapo.append(lpapoprot)
# add to lpapo information about the protein names
    lpapo.append(protnames)
# add 'N' to lpappo
    lpapo.append('N')
# add 'Y' to lpappo
    lpapo.append('Y')
# update lubpep in the index of the neoepitope (it was [] in other case)
    lubpep[int(eval(lpapo[0]))]=lpapo
# opens the file with the information of the locally ubiquous neoepitopes
  up=open('/home/l/localinformationmutations/output_coord_hg38_'+str(tum[i])+' annotated_for_mutations_local .txt',"r")
# creates a list with the records in the file
  with up as f:
    upc = f.readlines()
    upc = [x.strip() for x in upc]
  up.close()
# initialize the list 'localmut' of length equal to the number of mutations with values '[]' in all positions  
  localmut=[]
  for j in range(len(chb)):
    localmut.append([])
# initializes the counter of records
  cont=1
# loop on the locally ubiquous neoepitopes
  while upc[cont]!='END':
# reads index of mutation
    lpapo=[upc[cont]]
    cont=cont+1
# number of items associated to proteins in the mutation
    nrec=upc[cont]
# initialization of set of pairs position-protein id
    lpapoprot=[]
# initialization to the void set of the protein names
    protnames=set()
# loop in the proteins in the mutation
    for j in range(int(eval(nrec)/2)):
# recording of position-protein id
      lpapoprot.append([upc[cont+1],upc[cont+2]])
# update of set of the protein names
      protnames.add(upc[cont+2])
# update of counter associated to loop of proteins
      cont=cont+2
# update of counter associated to change of neoepitope
    cont=cont+1
# add to 'lpapo' information about position-protein id of the proteins
    lpapo.append(lpapoprot)
# add to lpapo information about the protein names
    lpapo.append(protnames)
# update localmut in the index of the neoepitope (it was [] in other case)
    localmut[int(eval(lpapo[0]))]=lpapo
# loop in the mutations  
  for j in range(len(chb)):
# tests if the mutation corresponds with an ubiquous neoepitope
    if lubpep[j]!=[]:
# tests if the variant type of the mutation is 'Insertion'
      if vtb[j]=='Insertion':
        print(j,'pasa insertion')
# labels the penultimate coordinate in the record of lubpep as 'I'
        lubpep[j][-2]='I'
# tests if the variant type of the mutation is 'Deletion'
      elif vtb[j]=='Deletion':
        print(j,'pasa deletion')
# labels the penultimate coordinate in the record of lubpep as 'D'
        lubpep[j][-2]='D'
# tests if the consequence of the mutation is 'synonymus variant'
      elif csb[j].find('synonymous_variant')!=-1:
# labels the penultimate coordinate in the record of lubpep as 'S'
        lubpep[j][-2]='S'

# tests if the consequence of the mutation is 'intron variant'
      elif csb[j].find('intron_variant')!=-1:
# labels the penultimate coordinate in the record of lubpep as 'IV'
        lubpep[j][-2]='IV'

# tests if the consequence of the mutation is 'non_coding transcript'
      elif csb[j].find('non_coding_transcript')!=-1:
# labels the penultimate coordinate in the record of lubpep as 'NCT'
        lubpep[j][-2]='NCT'
# in other case, that is, if it is a regular mutation
      else:
# reads the reading frame
        fnr=int(eval(lubpep[j][1]))
        print(j,"frame number=",fnr)
# opens the file containing the sequence of the chromosome
        strchr='/home/l/chromosomeshg19/'+str(chb[j])+'.fa'
        s=SeqIO.parse(strchr,"fasta")
# reads the sequence of the chromosome in sr
        for sr in s:
# reads from the file of neoepitopes the transcript
          strnscr=lubpep[j][2]
          print("pasatestar transcript de ensembldb: ",strnscr)
# reads from the chromosome the string, having into account the reading frame
          sgen=sr[pob[j]-fnr-3*r-1:pob[j]-fnr+2+3*r].seq
          print("pasatestar de cromosomas: ",sgen)
# calculates the reverse complement of the previous string
          rcsgen=sgen.reverse_complement()
# converts sgen to uppercase
          strsgen=str(sgen).upper()
# converts rcsgen to uppercase
          strrcsgen=str(rcsgen).upper()
# begins the calculation of the mutated sequence, initializing it to the non-mutated one
          mutantgen=strsgen
# splits the string in a list of its characters
          lmutantgen=list(mutantgen)
# prints the reference bases (more than one if it is a multiple mutation)
          print('reference:'+rab[j])
# prints the bases in the genome corresponding to the reference bases (having into account the reading frame)
          print("in genome: ",strsgen[3*r+fnr:3*r+fnr+len(rab[j])])
# prints the variant bases (more than one if it is a multiple mutation)
          print('variant:',vab[j])
# loop in the characters of the single or multiple variation
          for indvar in range(len(vab[j])):
# prints list of characters
            print(lmutantgen)
# prints index in lmutantgen corresponding to character of variation in the loop
            print(3*r+fnr-1+indvar)
# prints character of variation in the loop
            print(vab[j][indvar:indvar+1])
# changes element in lmutantgen according to the mutation
            lmutantgen[3*r+fnr+indvar]=vab[j][indvar:indvar+1]
# prints the new value of lmutantgen
          print(lmutantgen)
# converts again the list in a string
          mutantgen="".join(lmutantgen)
          print("mutated genetic sequence:"+mutantgen)
          print(strnscr)
          print(strsgen)
          print(strrcsgen)
# calculates the translation of the non-mutated sequence
          trnslseq=Seq(strnscr).translate()
# prints the non-mutated sequence
          print('non mutated peptide:'+trnslseq)
          nmp[j]=str(trnslseq)
# tests if the transcript from the file of neoepitopes equals the one obtained from the chromosomes
          if strnscr==strsgen:
# set the mode to 'direct' (rm='D')
            rm='D'
            print('direct mode')
# converts the mutated transcript to sequence
            trmutseq=Seq(mutantgen)
            print('mutated transcript:'+str(trmutseq))
# calculates the translation of the sequence of the mutated transcript
            trnslmutlseq=trmutseq.translate()
            print('mutated peptide:'+str(trnslmutlseq))
# labels the penultimate coordinate in the record of lubpep as the string of the translation of the sequence of the mutated transcript
            lubpep[j][-2]=str(trnslmutlseq)           
            print('number of differences:'+str(ndifferences(str(trnslseq), str(trnslmutlseq))))
# tests if the number of differences of aminoacides in the mutated string is greater than 1
            if ndifferences (str(trnslseq), str(trnslmutlseq))>1:
# labels the penultimate coordinate in the record of lubpep as multiple mutations of aminoacids ('MM')
              lubpep[j][-2]='MM'
# tests if there are no differences in the mutated string
            if ndifferences (str(trnslseq), str(trnslmutlseq))==0:
# labels the penultimate coordinate in the record of lubpep as synonim mutation ('SM') (it complements the annotation in the file of mutations)
              lubpep[j][-2]='SM'
# tests if there is an end of protein signal
            if trnslmutlseq.find('*')!=-1:
# labels the penultimate coordinate in the record of lubpep as non-sense mutation ('NS') (it complements the annotation in the file of mutations)
              lubpep[j][-2]='NS'
# tests if the transcript from the file of neoepitopes equals the reverse complement of the one obtained from the chromosomes
          elif strnscr==strrcsgen:
# set the mode to 'reverse complement' (rm='R')
            rm='R'
            print('reverse complement mode')
# takes the sequence of the reverse complement of the unoriented mutated transcript
            trmutseq=Seq(mutantgen).reverse_complement()
            print('mutated transcript:'+str(trmutseq))
# calculates the translation of the previous sequence
            trnslmutlseq=trmutseq.translate()
            print('mutated peptide:'+str(trnslmutlseq))
# labels the penultimate coordinate in the record of lubpep as the string of the previous sequence
            lubpep[j][-2]=str(trnslmutlseq)
            print('number of differences:'+str(ndifferences(str(trnslseq), str(trnslmutlseq))))
# tests if the number of differences of aminoacides in the mutated string is greater than 1
            if ndifferences(str(trnslseq), str(trnslmutlseq))>1:
# labels the penultimate coordinate in the record of lubpep as multiple mutations of aminoacids ('MM')
              lubpep[j][-2]='MM'
# tests if there are no differences in the mutated string
            if ndifferences (str(trnslseq), str(trnslmutlseq))==0:
# labels the penultimate coordinate in the record of lubpep as synonim mutation ('SM') (it complements the annotation in the file of mutations)
              lubpep[j][-2]='SM'
# tests if there is an end of protein signal
            if trnslmutlseq.find('*')!=-1:
              lubpep[j][-2]='NS'
# tests if the mode is not direct nor reverse complement (in this case there is an error in the databases)
          else:
# writes the ubiquous neoepitope in the error file
            ef.write(str(j)+" "+str(tum[i])+" "+str(strnscr)+" "+str(strsgen)+" "+str(strrcsgen)+"\n")
# labels the penultimate coordinate in the record of lubpep with an error code ('E')
            lubpep[j][-2]='E'
# loop in the mutations candidate to be ubiquous neoepitope
  for j in range(len(chb)):

# empieza testar-borrar
    if len(lubpep[j])>0:
      print(j,"  ",lubpep[j][-2])
# termina testar-borrar

# tests if there are annotations in the record in 'lubpep'
    if lubpep[j]!=[]:
# tests if if it is not an insertion, deletion, synonimous (in both comprobations,'S' and 'SM'), non-sense,non coding transcript, multiple mutations of aminoacids, intron variant or error     
      if (lubpep[j][-2]!='I') and (lubpep[j][-2]!='D') and (lubpep[j][-2]!='S') and (lubpep[j][-2]!='NCT') and (lubpep[j][-2]!='MM') and (lubpep[j][-2]!='SM') and (lubpep[j][-2]!='NS') and (lubpep[j][-2]!='IV') and (lubpep[j][-2]!='E'):
        print('pass al conditions')
# initializes to true the condition of no incompatibility with other neoepitopes codifying some common protein
        condpairs=True
# inner loop in the mutations to detect incompatibility
        for k in range(len(chb)):

# tests if the mutation is codifying and is an insertion or deletion
          if k!=j and (localmut[k]!=[]) and ((vtb[k]=='Insertion') or (vtb[k]=='Deletion')):
# records the proteins in the outer loop
            s1=lubpep[j][-3]
# records the proteins in the inner loop
            s2=localmut[k][-1]
# tests if there are proteins in common
            if (s1.intersection(s2))!=set():
              print('there is intersection with ',k,', which is ',s1.intersection(s2))
# change to false the condition of no incompatibility
              condpairs=False
# tests if, finally, there is no incompatibility with the proteins in other mutations
        if condpairs:
          print('no proteins in common')
# sets the condition that the mutation is not in germinal line, initially, to 'True'
          condgerm=True
# loop in the mutations in germinal line
          for indb in range(len(chgerm)):
            if (j==174):
              print(indb," ",'chr'+str(chgerm[indb])," ",str(chb[j])," ",'chr'+str(chgerm[indb])==str(chb[j])," ",str(pogerm[indb])," ",str(pob[j])," ",str(pogerm[indb])==str(pob[j]))
# tests if the mutations are in the same chromosome and position
            if ((('chr'+str(chgerm[indb])==str(chb[j])) or (str(chgerm[indb])=="23" and str(chb[j])=="chrX"))) and (str(pogerm[indb])==str(pob[j])):
# change the value of not being in germinal line to 'False'
              condgerm=False
# tests if, finally, the mutation is not in germinal line
          if condgerm:
            print('the mutation is not in germinal line')
# adds the ubiquous neoepitope to the file
            oneoep.write(lubpep[j][-2]+"\n")
# adds the information to the summary file
            summ.write('j (from 0)='+str(j)+', non-mutated='+nmp[j]+", mutated="+lubpep[j][-2]+"\n")
# adds the information to the file of variant frequencies
            vf.write(lubpep[j][-2]+", "+str(cvf[j])+"\n")
# closes the file of errors
ef.close
# closes the file in which the neoepitopes are written
oneoep.close


      
 
