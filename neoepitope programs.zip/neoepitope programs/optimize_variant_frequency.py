import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

# function to normalize a sequence
def norm(seq):
    maxseq=max(seq)
    minseq=min(seq)
    if maxseq==0 and minseq==0:
      normseq=seq
    else:
      normseq=[]
      for indnorm in range(len(seq)):
          normseq.append((seq[indnorm]-minseq)/(maxseq-minseq))
    return normseq

listnepit=[20,52,10,46,22,9]

rvf=open("results_variant_frequency.txt","w")
# opens the file in which the hla1 binding affinity are written (with an empty line at the beginning!)
fvf=open("variant_frequencies_non_normalized.txt","r")
# loop on the patients
for x in listnepit:
# initialize list of epitopes
  lepit=[]
# initialize list of variant frequencies
  vvf=[]
# reads blank line
  bl=fvf.readline()
# writtes blank line
  rvf.write("\n")
# reads patient code
  np=fvf.readline()[:-1]
  print(np)
  rvf.write(np+"\n")
# loop on neoepitopes of the patient
  for i in range(x):

    hrl=fvf.readline()[:-1].split(",")

# adds neoepitope to list (removing the endline)
    lepit.append(hrl[0])


# reads variant frequency value
    vf=eval(hrl[1])
    print(vf)
# adds variant frequency value to list
    vvf.append(vf)
  print(vvf)
# normalizes the list of variant frequency values
  vvfbis=norm(vvf)
  print(vvfbis)
  print(lepit)
  for i in range(x):
    rvf.write(lepit[i]+","+str(vvfbis[i])+"\n")


      
 
