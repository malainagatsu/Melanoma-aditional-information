import sys
import Bio
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from pandas import DataFrame, read_csv
from termcolor import colored
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from Bio.Alphabet import IUPAC
from pyliftover import LiftOver

import statistics
import itertools

listnepit=[20,52,10,46,22,9]
# opens the file in which the immunogenicities are written (with an empty line at the beginning!)
ri=open("results_immunogenicity.txt","r")
# opens the file in which the hydrophilicities are written (with an empty line at the beginning!)
rh=open("results_hydrophilicity.txt","r")
# opens the file in which the vaxijen values are written (with an empty line at the beginning!)
rv=open("results_vaxijen.txt","r")
# opens the file in which the hla1 binding affinity values are written (with an empty line at the beginning!)
rhla1=open("results_hla1.txt","r")
# opens the file in which the hla2 binding affinity values are written (with an empty line at the beginning!)
rhla2=open("results_hla2.txt","r")
# opens the file in which the hla2 binding affinity values are written (with an empty line at the beginning!)
rtpr=open("results_TAP_proteo.txt","r")
# opens the file in which the variant frequency values are written (with an empty line at the beginning!)
rvf=open("results_variant_frequency.txt","r")
# loop on the patients
for x in listnepit:
# initialize the maximum of the fitness function
  maxf=-1
# initialize the tuple corresponding to the maximum of the fitness function
  maxt=()
# initialize list of immunogenicities
  limm=[]
# initialize list of immunogenicities
  lhydr=[]
# initialize list of vaxijen values
  lvax=[]
# initialize list of hla1 values
  lhla1=[]
# initialize list of hla2 values
  lhla2=[]
# initialize list of TAP proteo values
  ltpr=[]
# initialize list of variant frequency values
  lvf=[]
# reads blank line
  bl=ri.readline()
  bl2=rh.readline()
  bl3=rv.readline()
  bl4=rhla1.readline()
  bl5=rhla2.readline()
  bl6=rtpr.readline()
  bl7=rvf.readline()
# reads patient code
  np=ri.readline()[:-1]
  np2=rh.readline()[:-1]
  np3=rv.readline()[:-1]
  np4=rhla1.readline()[:-1]
  np5=rhla2.readline()[:-1]
  np6=rtpr.readline()[:-1]
  np7=rvf.readline()[:-1]
  print(np)
  listneoep=[]
# loop on neoepitopes of the patient
  for i in range(x):

    lrecordinm=ri.readline()[:-1].split(",")
# reads neoepitope
    listneoep.append(lrecordinm[0])

# reads immunogenicity
    
    inmm=eval(lrecordinm[1])
# adds immunogenicity to list
    limm.append(inmm)
# reads hydrophilicity
    hydr=eval(rh.readline()[:-1].split(",")[1])
# adds hydrophilicity to list
    lhydr.append(hydr)
# reads vaxijen
    vaxijen=eval(rv.readline()[:-1].split(",")[1])
# adds vaxijen value to list
    lvax.append(vaxijen)



# reads hla1
    hla1=eval(rhla1.readline()[:-1].split(",")[1])
# adds hla1 value to list
    lhla1.append(hla1)

# reads hla2
    hla2=eval(rhla2.readline()[:-1].split(",")[1])
# adds hla2 value to list
    lhla2.append(hla2)

# reads htpr
    htpr=eval(rtpr.readline()[:-1].split(",")[1])
# adds htpr value to list
    ltpr.append(htpr)


# reads hvf
    hvf=eval(rvf.readline()[:-1].split(",")[1])
# adds hvf value to list
    lvf.append(hvf)

  l=list(itertools.combinations(range(x),6))
  for i in l:
    s=0
    for j in range(6):
      s=s+0.2*limm[i[j]]+0.1*lhydr[i[j]]+0.1*lvax[i[j]]+0.2*lhla1[i[j]]+0.2*lhla2[i[j]]+0.1*ltpr[i[j]]+0.1*lvf[i[j]]
    if s>maxf:
      maxf=s
      maxt=i
  print("max s="+str(maxf)+"\n")
  print("indexes (from 0) of the neoepitopes giving the maximum="+str(maxt)+"\n")
  lneoepmax=[]
  for infneom in range(6):
    lneoepmax.append(listneoep[maxt[infneom]])
  print("neoepitopes giving the maximum="+str(lneoepmax)+"\n")
  print(bl)




      
 
